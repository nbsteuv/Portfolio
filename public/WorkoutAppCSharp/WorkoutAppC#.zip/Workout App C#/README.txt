Run this app by running the WorkoutApp.exe file.

Your workout data will be stored in the Workouts folder by default.

The exercise lists control which exercises are available in each muscle group category.

Enjoy!